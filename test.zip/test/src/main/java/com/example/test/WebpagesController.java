package com.example.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class WebpagesController {

    @Autowired
    UserRepository userRepo;

    @GetMapping("")
    public String home() {
        return "index.html";
    }

    @GetMapping("/user")
    @ResponseBody
    public String user() {
        return "welcome user";
    }

    @GetMapping("/admin")
    @ResponseBody
    public String admin() {
        return "welcome admin";
    }
}
